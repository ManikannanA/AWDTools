import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ReadExample {

	public static void main(String[] args) throws SAXException, IOException {

		try {
			File xmlFile = new File("F:\\LOB\\lob.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlFile);

			NodeList nodes = doc.getElementsByTagName("AWD");
			for (int i = 0; i < nodes.getLength(); i++) {
				Element element = (Element) nodes.item(i);
				NodeList title = element.getElementsByTagName("TASK");
				Element line = (Element) title.item(0);

				NodeList content = element.getChildNodes();
				StringBuilder textContent = new StringBuilder();
				int cntLength = content.getLength();
				System.out.println("cntLength>>>>>>>>>>>" + cntLength);
				for (int j = 0; j < cntLength; j++) {
					Node paramValue = content.item(j);
					short type = paramValue.getNodeType();
					if ((type == Node.TEXT_NODE) || (type == Node.CDATA_SECTION_NODE)) {
						textContent.append(((CharacterData) paramValue).getData());
						// Both Text and CDATASection nodes are SubType of CharacterData
					}
				}
				String task = getCharacterDataFromElement(line);
				System.out.println("TASK: " + task);
			}
			// String task =getCharacterDataFromElement(line);
			// NodeList createInstences = doc.getElementsByTagName("createInstences");
			// Element element = (Element) nodes.item(i);
			// NodeList title = element.getElementsByTagName("createInstence");
			// Element line = (Element) title.item(0);

			NodeList fieldValues = doc.getElementsByTagName("fieldValues");
			for (int i = 0; i < fieldValues.getLength(); i++) {
				Node node = fieldValues.item(i);
				if (!(node instanceof Element))
					continue;
				Element e = (Element) node;
				String name = e.getAttributeNode("name").getValue();
				if ("IDFY".equals(name)) {
					System.out.println("<<<<<<<<<<<<<<<<<Node Value>>>>>>>>>>>>>>>");
				}
			}
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
	}

	public static String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
			CharacterData cd = (CharacterData) child;
			return cd.getData();
		}
		return "";
	}
}
