package net.nwie.awdtool;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class LOBTruncationTool {

	public static void main(String[] args) throws Exception {
		String filePath = "lob_updated.xml";
		File xmlFile = new File(filePath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();

			Document docUpdate = dBuilder.parse(xmlFile);
			// update attribute value
			docUpdate = updateAttributeValue(doc);

			// write the updated document to file or console
			//doc.getDocumentElement().normalize();

			// updateFiedldValue();
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(docUpdate);
			StreamResult result = new StreamResult(new File(filePath));
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(source, result);

			/*
			 * DOMSource domSource = new DOMSource(doc); StreamResult Updatedresult = new
			 * StreamResult(new File("Data.xml")); transformer.transform(source,
			 * Updatedresult);
			 */

			System.out.println("XML file updated successfully");
		} catch (SAXException | ParserConfigurationException | IOException | TransformerException e1) {
			e1.printStackTrace();
		}
	}

	private static Document updateAttributeValue(Document doc) throws Exception {
		NodeList nodes = doc.getElementsByTagName("AWD");
		Element element = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		//DocumentBuilder builder;

		Document cdataDoc=null;
		
		// loop for each fieldvalues

		for (int i = 0; i < nodes.getLength(); i++) {
			element = (Element) nodes.item(i);
			NodeList cdataParent = element.getElementsByTagName("TASK");
			//Element line = (Element) cdataParent.item(0);
			//String task = getCdata(line);
			//System.out.println("TASK: " + task);
			DocumentBuilder cdataBuilder = factory.newDocumentBuilder();

			// Use method to convert XML string content to XML Document object

			cdataDoc = cdataBuilder.parse(new InputSource(new StringReader(getCdata(cdataParent.item(0)))));
			Node businessAreaName = cdataDoc.getElementsByTagName("businessAreaName").item(0);
			System.out.println("Content of businessAreaName in CDATA: " + getCdata(businessAreaName));

			NodeList iParent = cdataDoc.getElementsByTagName("fieldValues");
			System.out.println("iParent: " + iParent.getLength());

			for (int j = 0; j < iParent.getLength(); j++) {
				// element = (Element) nodes.item(i);
				cdataDoc = cdataBuilder.parse(new InputSource(new StringReader(getCdata(cdataParent.item(0)))));
				NodeList insParent = cdataDoc.getElementsByTagName("fieldValue");

				System.out.println("Inside the filedValue Subnode: " + insParent.item(0).getNodeName());

				for (int k = 0; k < insParent.getLength(); k++) {
					element = (Element) nodes.item(i);
					//cdataDoc = cdataBuilder.parse(new InputSource(new StringReader(getCdata(cdataParent.item(0)))));
					insParent = cdataDoc.getElementsByTagName("value");
					System.out.println("<Value>:>>>>>>" + insParent.item(k).getFirstChild().getNodeValue());
					String output = getCdata(insParent.item(k));
					System.out.println("Value Original tag outputValue: " + output);
					if (output.length() > 2) {
						System.out.println("FieldValue  after truncate : " + output.substring(0, 2));
						insParent.item(k).getFirstChild().setNodeValue(output.substring(0,2));
						System.out.println("Value :" + insParent.item(k).getFirstChild().getNodeValue() );
					} 
				}
			}
		}
		return cdataDoc;
	}

	/*public static void updateFiedldValue() {
		try {
			String filePath = "lob.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filePath);

			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			transformerFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			StringWriter output = new StringWriter();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filePath));
			transformer.transform(source, result);
			// transformer.clearParameters();
			// transformer.transform(new DOMSource(source), new StreamResult(output));
			// transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			// DOMSource source = new DOMSource(doc);

			String xmlString = result.getWriter().toString();
			System.out.println(xmlString);

			System.out.println("Done");

		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
*/
	public static String getCdata(Node parent) {
		NodeList cs = parent.getChildNodes();
		for (int i = 0; i < cs.getLength(); i++) {
			Node c = cs.item(i);
			if (c instanceof CharacterData) {
				CharacterData cdata = (CharacterData) c;
				String content = cdata.getData().trim();
				if (content.length() > 0) {
					return content;
				}
			}
		}
		return "";
	}

}
