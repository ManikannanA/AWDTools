package net.nwie.awdtool;

import java.io.File;
import java.io.FileFilter;

public class WildcardFileFilter implements FileFilter {

	public WildcardFileFilter(String string) {
		// TODO Auto-generated constructor stub
	}

	public boolean accept(File pathname) {
		// TODO Auto-generated method stub
		return false;
	}

}
