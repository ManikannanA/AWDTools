package net.nwie.awdtool;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;

public class AWDFileHandler {

	static String sourcePath = "F:\\AWD\\docvault\\recovery";
	static String destinationPath = "F:\\AWD\\docvault\\success";

	public static void main(String[] args) {
		File sourceDir = new File(sourcePath);
		File[] nameFilterfiles = sourceDir.listFiles(nameFilter);
		moveFile(nameFilterfiles);
		File[] sizeFilterfiles = sourceDir.listFiles(sizeFilter);
		moveFile(sizeFilterfiles);
	}

	private static void moveFile(File[] files) {

		File destDir = new File(destinationPath);
		if (files.length == 0) {
			System.out.println("There is no less than 1kb files in recovery folder");
		} else {
			for (File aFile : files) {
				try {
					if (!destDir.exists()) {
						destDir.mkdir();
					} else {
						aFile.renameTo(new File(destDir + "\\" + aFile.getName()));
						System.out.println(aFile.getName() + " - " + aFile.length());
					}
				} catch (Exception exp) {
					System.out.println(exp);
				}

			}
		}
	}

	static FilenameFilter nameFilter = new FilenameFilter() {
		public boolean accept(File file, String name) {
			if (name.contains("csr-void")) {
				// filters files whose extension is.txt
				return true;
			} else {
				return false;
			}
		}
	};

	static FileFilter sizeFilter = new FileFilter() {
		public boolean accept(File file) {
			if (file.isFile() && file.length() <= 1 * 1024) {
				// filters files whose size less than or equal to 1MB
				return true;
			} else {
				return false;
			}
		}
	};
}
