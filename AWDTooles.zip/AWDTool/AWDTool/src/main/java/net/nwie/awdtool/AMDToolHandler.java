package net.nwie.awdtool;


import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.nio.file.Path;
import java.nio.file.Paths;

public class AMDToolHandler {

	static String sourcePath = "F:\\docvault\\recovery";
	static String destinationPath = "F:\\\\docvault\\success";
	static String searchFileLocation= "F:\\server\\success";
	
	public static void main(String[] args) {
		File sourceDir = new File(sourcePath);
	/*	File[] nameFilterfiles = sourceDir.listFiles(nameFilter);
		moveFile(nameFilterfiles);
		File[] sizeFilterfiles = sourceDir.listFiles(sizeFilter);
		moveFile(sizeFilterfiles);*/
		File[] searchFilterfiles = sourceDir.listFiles(searchFilter);
		searchFile(searchFilterfiles);
	}

	private static void searchFile(File[] files) {
		
		File destDir = new File(destinationPath);
		if (files.length == 0) {
		    System.out.println("There is no such files");
		} else {
		    for (File aFile : files) {
		    	try {
		    		if(!destDir.exists()) {
		    			destDir.mkdir();
		    		}else {
		    			if(aFile.getName().contains("_fn-awd-")) {
		    				File searchDir = new File(searchFileLocation);
		    				Path path = Paths.get(aFile.getName()); 
		    		        Path fileName = path.getFileName();
		    		        String str =fileName.toString();
		    		        String fileStr = str.substring(0, str.lastIndexOf('.'));
		    		        System.out.println("Out "+fileStr);
		    				FileFilter wildCardFilter = new WildcardFileFilter(fileStr + "*");
		    				File[] searchFilterfiles = searchDir.listFiles(wildCardFilter);
		    				for (File xmlFile : searchFilterfiles) {
		    				   System.out.println(xmlFile.getName());
		    				}
		    			}
		    			
		    		}
		    	}catch(Exception exp) {
		    		System.out.println(exp);
		    	}
		    	
		    }
		}
	}

	private static void moveFile(File[] files) {
		
		File destDir = new File(destinationPath);
		if (files.length == 0) {
		    System.out.println("There is no such files");
		} else {
		    for (File aFile : files) {
		    	try {
		    		if(!destDir.exists()) {
		    			destDir.mkdir();
		    		}else {
		    			aFile.renameTo(new File(destDir + "\\" + aFile.getName()));
				        System.out.println(aFile.getName() + " - " + aFile.length());
		    		}
		    	}catch(Exception exp) {
		    		System.out.println(exp);
		    	}
		    	
		    }
		}
	}
	
	/*static FilenameFilter nameFilter = new FilenameFilter() {
	    public boolean accept(File file, String name) {
	        if (name.contains("PaymentSummary")) {
	            // filters files whose extension is PaymentSummary
	            return true;
	        } else {
	            return false;
	        }
	    }
	};
	
	static FileFilter sizeFilter = new FileFilter() {
	    public boolean accept(File file) {
	        if (file.isFile() && file.length() <= 1*1024*1024) {
	            // filters files whose size less than or equal to 1MB
	            return true;
	        } else {
	            return false;
	        }
	    }
	};*/
	
	static FileFilter searchFilter = new FileFilter() {
	    public boolean accept(File file) {
	        if (file.isFile() && file.length() <= 1*1024) {
	            // filters files whose size less than or equal to 1MB
	            return true;
	        } else {
	            return false;
	        }
	    }
	};
	
	public static String removeExtension(String s) {

	    String separator = System.getProperty("file.separator");
	    String filename;

	    // Remove the path upto the filename.
	    int lastSeparatorIndex = s.lastIndexOf(separator);
	    if (lastSeparatorIndex == -1) {
	        filename = s;
	    } else {
	        filename = s.substring(lastSeparatorIndex + 1);
	    }

	    // Remove the extension.
	    int extensionIndex = filename.lastIndexOf(".");
	    if (extensionIndex == -1)
	        return filename;

	    return filename.substring(0, extensionIndex);
	}
	
}
